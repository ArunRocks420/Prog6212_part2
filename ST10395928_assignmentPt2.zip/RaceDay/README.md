# RaceDay — Part 2: RESTful API

A full-stack event management API for South African road running, walking and
cycling events, built with ASP.NET Core Web API (C#), Entity Framework Core
(Code-First), and SQL Server. This is Part 2 of the PROG6212 Portfolio of
Evidence — it implements the endpoint plan produced in Part 1.

## Roles

RaceDay has two roles, selected at registration:

- **Organiser** — creates and manages events, categories and routes; views
  the roster of participants enrolled in their events; captures finish
  times/positions after a race.
- **Participant** — browses public events and categories; enters (enrols
  in) a category; tracks their own enrolment and results history.

A user is only ever one role. Organiser-only actions (creating an event,
capturing a result) are rejected with `403 Forbidden` if attempted by a
Participant, and vice versa. Anonymous requests to protected endpoints are
rejected with `401 Unauthorized`.

## Authentication model

The brief requires **session management**, not token-based auth. On login,
the API stores `UserId` and `Role` in an ASP.NET Core server-side session and
returns a session cookie (`RaceDay.Session`). The browser (or Swagger UI, or
a test HTTP client with cookie handling enabled) sends that cookie
automatically on every subsequent request, and two custom action filters
enforce it:

- `[RequireSessionAuth]` — any logged-in user.
- `[RequireRole("Organiser")]` / `[RequireRole("Participant")]` — a specific role.

Passwords are never stored in plain text. They are hashed with PBKDF2-SHA256
(100,000 iterations, random 128-bit salt per user) using
`System.Security.Cryptography.Rfc2898DeriveBytes`, which ships with .NET —
no extra package required.

## Project structure

```
RaceDay.Api/          ASP.NET Core Web API project
  Models/              EF Core entities (Users, Events, Routes, Categories, Enrolments, Results)
  Data/                 RaceDayDbContext (Code-First, Fluent API configuration)
  Security/             PasswordHasher
  Auth/                 SessionKeys, RequireSessionAuthAttribute, RequireRoleAttribute
  DTOs/                 Request/response models per feature area
  Controllers/          AuthController, UsersController, EventsController,
                         CategoriesController, RoutesController,
                         EnrolmentsController, ResultsController
RaceDay.Tests/         xUnit integration tests (via WebApplicationFactory + EF InMemory)
.github/workflows/     GitHub Actions CI/CD (build + test on every push)
docs/                  Part 1 planning artifacts, including the updated ERD/SQL (see below)
```

## Setup and run instructions

**Prerequisites:** Visual Studio 2022 (or the .NET 9 SDK), SQL Server /
SQL Server Express, SSMS.

1. Clone the repository and open `RaceDay.sln` in Visual Studio.
2. Update the connection string in `RaceDay.Api/appsettings.json` to point
   at your SQL Server instance:
   ```json
   "ConnectionStrings": {
     "RaceDayDB": "Server=YOUR_SERVER;Database=RaceDayDB;Trusted_Connection=True;TrustServerCertificate=True;"
   }
   ```
3. Create the database using EF Core migrations (Code-First):
   ```
   cd RaceDay.Api
   dotnet ef migrations add InitialCreate
   dotnet ef database update
   ```
   (Alternatively, run `docs/RaceDay_Database_Part1_UPDATED.sql` directly in
   SSMS — it matches this project's schema exactly, including the Part 2
   additions described below.)
4. Run the API:
   ```
   dotnet run --project RaceDay.Api
   ```
   or press **F5** in Visual Studio. Swagger UI opens automatically at
   `/swagger`.
5. Run the tests:
   ```
   dotnet test
   ```

## Deviations from the Part 1 plan

The Part 2 Functional Requirements state that each event must capture **"a
name, description, date, location, distance, and event type (run, walk, or
cycle)."** The original Part 1 ERD and SQL script did not include `Distance`
or `EventType` on the `Events` entity. Both were added here:

- `Events.Distance` — `DECIMAL(6,2)`
- `Events.EventType` — `VARCHAR(10)`, constrained to `Run` / `Walk` / `Cycle`

The updated ERD and SQL script reflecting this change are in `docs/`
(`RaceDay_ERD_Part1_UPDATED.png`, `RaceDay_Database_Part1_UPDATED.sql`); new
fields are highlighted in the ERD. No other structural changes were made —
everything else matches the original Part 1 submission.

A second, minor addition: a unique constraint on `(ParticipantID,
CategoryID)` in `Enrolments`, enforcing the business rule that a participant
may only enter a given category once. This wasn't explicit in the Part 1
script but follows directly from "the system must record the link between
the Participant, the event, and the selected category."

## CI/CD

GitHub Actions (`.github/workflows/dotnet-ci.yml`) restores, builds and runs
the full test suite on every push to `main` or `part2-api`, and on pull
requests into `main`.

**[Insert screenshot of a successful green Actions run here.]**

## Demo video

**[Insert unlisted YouTube link here — demonstrate the running API, explain
the code structure, endpoints, authentication, and unit tests.]**
