using System.Net.Http.Json;

namespace RaceDay.Tests
{
    internal static class HttpClientJsonExtensions
    {
        public static Task<HttpResponseMessage> PostJsonAsync<T>(this HttpClient client, string url, T body) =>
            client.PostAsJsonAsync(url, body);

        public static Task<HttpResponseMessage> PutJsonAsync<T>(this HttpClient client, string url, T body) =>
            client.PutAsJsonAsync(url, body);
    }
}
