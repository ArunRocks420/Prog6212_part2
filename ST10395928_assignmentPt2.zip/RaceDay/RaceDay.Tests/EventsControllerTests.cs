using System.Net;
using System.Net.Http.Json;
using RaceDay.Api.DTOs.Auth;
using RaceDay.Api.DTOs.Events;
using RaceDay.Api.Models;
using Xunit;

namespace RaceDay.Tests
{
    public class EventsControllerTests : IClassFixture<CustomWebApplicationFactory>
    {
        private readonly CustomWebApplicationFactory _factory;

        public EventsControllerTests(CustomWebApplicationFactory factory)
        {
            _factory = factory;
        }

        private static CreateEventRequest SampleEvent(string name) => new()
        {
            EventName = name,
            Description = "A test event.",
            EventDate = DateTime.UtcNow.AddMonths(2),
            Location = "Cape Town",
            Distance = 21.1m,
            EventType = EventType.Run
        };

        private async Task<HttpClient> LoggedInClientAsync(string email, string role)
        {
            var client = _factory.CreateSessionAwareClient();

            await client.PostJsonAsync("/api/auth/register", new RegisterRequest
            {
                FirstName = "Test",
                LastName = "User",
                Email = email,
                Password = "SecurePass123",
                Role = role
            });

            await client.PostJsonAsync("/api/auth/login", new LoginRequest
            {
                Email = email,
                Password = "SecurePass123"
            });

            return client;
        }

        [Fact]
        public async Task CreateEvent_AsOrganiser_ReturnsCreated()
        {
            var client = await LoggedInClientAsync("organiser.create1@test.com", UserRoles.Organiser);

            var response = await client.PostJsonAsync("/api/events", SampleEvent("Comrades Marathon"));

            Assert.Equal(HttpStatusCode.Created, response.StatusCode);
            var body = await response.Content.ReadFromJsonAsync<EventDto>();
            Assert.Equal("Comrades Marathon", body!.EventName);
            Assert.Equal("Run", body.EventType);
        }

        [Fact]
        public async Task CreateEvent_AsParticipant_ReturnsForbidden()
        {
            var client = await LoggedInClientAsync("participant.create1@test.com", UserRoles.Participant);

            var response = await client.PostJsonAsync("/api/events", SampleEvent("Should Not Be Created"));

            Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
        }

        [Fact]
        public async Task CreateEvent_WithoutLogin_ReturnsUnauthorized()
        {
            var client = _factory.CreateSessionAwareClient(); // never logged in

            var response = await client.PostJsonAsync("/api/events", SampleEvent("Anonymous Event"));

            Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
        }

        [Fact]
        public async Task GetEvents_IsPublic_ReturnsOk()
        {
            var client = _factory.CreateSessionAwareClient(); // never logged in

            var response = await client.GetAsync("/api/events");

            Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        }

        [Fact]
        public async Task UpdateEvent_AsNonOwningOrganiser_ReturnsForbidden()
        {
            var owner = await LoggedInClientAsync("owner.organiser1@test.com", UserRoles.Organiser);
            var createResponse = await owner.PostJsonAsync("/api/events", SampleEvent("Soweto Marathon"));
            var created = await createResponse.Content.ReadFromJsonAsync<EventDto>();

            var otherOrganiser = await LoggedInClientAsync("other.organiser1@test.com", UserRoles.Organiser);
            var updateResponse = await otherOrganiser.PutJsonAsync(
                $"/api/events/{created!.EventId}", SampleEvent("Hijacked Event Name"));

            Assert.Equal(HttpStatusCode.Forbidden, updateResponse.StatusCode);
        }
    }
}
