using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using RaceDay.Api.Data;

namespace RaceDay.Tests
{
    /// <summary>
    /// Boots the real RaceDay.Api pipeline (including session middleware and the
    /// RequireSessionAuth/RequireRole filters) for integration-style tests, but
    /// swaps the SQL Server DbContext for an isolated EF Core InMemory database
    /// so no actual SQL Server instance is required to run the tests.
    /// </summary>
    public class CustomWebApplicationFactory : WebApplicationFactory<Program>
    {
        public string DatabaseName { get; } = $"RaceDayTestDb_{Guid.NewGuid()}";

        protected override void ConfigureWebHost(IWebHostBuilder builder)
        {
            builder.ConfigureServices(services =>
            {
                var descriptor = services.SingleOrDefault(
                    d => d.ServiceType == typeof(DbContextOptions<RaceDayDbContext>));
                if (descriptor is not null) services.Remove(descriptor);

                services.AddDbContext<RaceDayDbContext>(options =>
                    options.UseInMemoryDatabase(DatabaseName));
            });
        }

        /// <summary>A client with cookie handling enabled, so the session cookie set
        /// at login is sent automatically on subsequent requests from this client.</summary>
        public HttpClient CreateSessionAwareClient() =>
            CreateClient(new WebApplicationFactoryClientOptions { HandleCookies = true });
    }
}
