using System.Net;
using System.Net.Http.Json;
using RaceDay.Api.DTOs.Auth;
using Xunit;

namespace RaceDay.Tests
{
    public class AuthControllerTests : IClassFixture<CustomWebApplicationFactory>
    {
        private readonly HttpClient _client;

        public AuthControllerTests(CustomWebApplicationFactory factory)
        {
            _client = factory.CreateSessionAwareClient();
        }

        [Fact]
        public async Task Register_WithValidData_ReturnsCreated()
        {
            var request = new RegisterRequest
            {
                FirstName = "Lindiwe",
                LastName = "Dlamini",
                Email = "lindiwe.register1@test.com",
                Password = "SecurePass123",
                Role = "Participant"
            };

            var response = await _client.PostJsonAsync("/api/auth/register", request);

            Assert.Equal(HttpStatusCode.Created, response.StatusCode);
            var body = await response.Content.ReadFromJsonAsync<AuthResponse>();
            Assert.NotNull(body);
            Assert.Equal("Participant", body!.Role);
            Assert.True(body.UserId > 0);
        }

        [Fact]
        public async Task Register_WithDuplicateEmail_ReturnsConflict()
        {
            var request = new RegisterRequest
            {
                FirstName = "Thabo",
                LastName = "Nkosi",
                Email = "thabo.duplicate@test.com",
                Password = "SecurePass123",
                Role = "Organiser"
            };

            var first = await _client.PostJsonAsync("/api/auth/register", request);
            Assert.Equal(HttpStatusCode.Created, first.StatusCode);

            var second = await _client.PostJsonAsync("/api/auth/register", request);
            Assert.Equal(HttpStatusCode.Conflict, second.StatusCode);
        }

        [Fact]
        public async Task Register_WithInvalidRole_ReturnsBadRequest()
        {
            var request = new RegisterRequest
            {
                FirstName = "Jane",
                LastName = "Doe",
                Email = "jane.badrole@test.com",
                Password = "SecurePass123",
                Role = "Admin" // not a valid RaceDay role
            };

            var response = await _client.PostJsonAsync("/api/auth/register", request);
            Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
        }

        [Fact]
        public async Task Login_WithValidCredentials_ReturnsOk()
        {
            var register = new RegisterRequest
            {
                FirstName = "Sarah",
                LastName = "Botha",
                Email = "sarah.login1@test.com",
                Password = "SecurePass123",
                Role = "Organiser"
            };
            await _client.PostJsonAsync("/api/auth/register", register);

            var login = new LoginRequest { Email = register.Email, Password = register.Password };
            var response = await _client.PostJsonAsync("/api/auth/login", login);

            Assert.Equal(HttpStatusCode.OK, response.StatusCode);
            var body = await response.Content.ReadFromJsonAsync<AuthResponse>();
            Assert.Equal("Organiser", body!.Role);
        }

        [Fact]
        public async Task Login_WithWrongPassword_ReturnsUnauthorized()
        {
            var register = new RegisterRequest
            {
                FirstName = "James",
                LastName = "van der Merwe",
                Email = "james.wrongpw@test.com",
                Password = "SecurePass123",
                Role = "Participant"
            };
            await _client.PostJsonAsync("/api/auth/register", register);

            var login = new LoginRequest { Email = register.Email, Password = "WrongPassword" };
            var response = await _client.PostJsonAsync("/api/auth/login", login);

            Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
        }

        [Fact]
        public async Task Login_WithUnknownEmail_ReturnsUnauthorized()
        {
            var login = new LoginRequest { Email = "nobody@test.com", Password = "WhateverPassword1" };
            var response = await _client.PostJsonAsync("/api/auth/login", login);

            Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
        }
    }
}
