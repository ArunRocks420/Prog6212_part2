using System.Net;
using System.Net.Http.Json;
using RaceDay.Api.DTOs.Auth;
using RaceDay.Api.DTOs.Categories;
using RaceDay.Api.DTOs.Enrolments;
using RaceDay.Api.DTOs.Events;
using RaceDay.Api.Models;
using Xunit;

namespace RaceDay.Tests
{
    public class EnrolmentsControllerTests : IClassFixture<CustomWebApplicationFactory>
    {
        private readonly CustomWebApplicationFactory _factory;

        public EnrolmentsControllerTests(CustomWebApplicationFactory factory)
        {
            _factory = factory;
        }

        private async Task<HttpClient> LoggedInClientAsync(string email, string role)
        {
            var client = _factory.CreateSessionAwareClient();

            await client.PostJsonAsync("/api/auth/register", new RegisterRequest
            {
                FirstName = "Test",
                LastName = "User",
                Email = email,
                Password = "SecurePass123",
                Role = role
            });

            await client.PostJsonAsync("/api/auth/login", new LoginRequest { Email = email, Password = "SecurePass123" });
            return client;
        }

        /// <summary>Creates an event with one category, as an Organiser, and returns the category id.</summary>
        private async Task<int> CreateEventWithCategoryAsync(HttpClient organiserClient)
        {
            var eventResponse = await organiserClient.PostJsonAsync("/api/events", new CreateEventRequest
            {
                EventName = "Cape Town Cycle Tour",
                Description = "Premier timed cycling event.",
                EventDate = DateTime.UtcNow.AddMonths(3),
                Location = "Cape Town",
                Distance = 109m,
                EventType = EventType.Cycle
            });
            var ev = await eventResponse.Content.ReadFromJsonAsync<EventDto>();

            var categoryResponse = await organiserClient.PostJsonAsync(
                $"/api/events/{ev!.EventId}/categories", new CreateCategoryRequest
                {
                    CategoryName = "109km",
                    DistanceKM = 109m,
                    EntryFee = 650m,
                    MaxParticipants = 2
                });
            var category = await categoryResponse.Content.ReadFromJsonAsync<CategoryDto>();

            return category!.CategoryId;
        }

        [Fact]
        public async Task Enrol_AsParticipant_ReturnsCreatedAndRecordsLink()
        {
            var organiser = await LoggedInClientAsync("organiser.enrol1@test.com", UserRoles.Organiser);
            var categoryId = await CreateEventWithCategoryAsync(organiser);

            var participant = await LoggedInClientAsync("participant.enrol1@test.com", UserRoles.Participant);
            var response = await participant.PostJsonAsync($"/api/categories/{categoryId}/enrolments", new { });

            Assert.Equal(HttpStatusCode.Created, response.StatusCode);
            var body = await response.Content.ReadFromJsonAsync<EnrolmentDto>();
            Assert.Equal(categoryId, body!.CategoryId);
            Assert.False(string.IsNullOrWhiteSpace(body.BibNumber));
        }

        [Fact]
        public async Task Enrol_AsOrganiser_ReturnsForbidden()
        {
            var organiser = await LoggedInClientAsync("organiser.enrol2@test.com", UserRoles.Organiser);
            var categoryId = await CreateEventWithCategoryAsync(organiser);

            // The same organiser tries to enrol in their own category - not allowed, Organiser role is blocked.
            var response = await organiser.PostJsonAsync($"/api/categories/{categoryId}/enrolments", new { });

            Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
        }

        [Fact]
        public async Task Enrol_Twice_ReturnsConflict()
        {
            var organiser = await LoggedInClientAsync("organiser.enrol3@test.com", UserRoles.Organiser);
            var categoryId = await CreateEventWithCategoryAsync(organiser);

            var participant = await LoggedInClientAsync("participant.enrol3@test.com", UserRoles.Participant);
            var first = await participant.PostJsonAsync($"/api/categories/{categoryId}/enrolments", new { });
            var second = await participant.PostJsonAsync($"/api/categories/{categoryId}/enrolments", new { });

            Assert.Equal(HttpStatusCode.Created, first.StatusCode);
            Assert.Equal(HttpStatusCode.Conflict, second.StatusCode);
        }

        [Fact]
        public async Task Enrol_WhenCategoryFull_ReturnsConflict()
        {
            // MaxParticipants = 2 for this category (see CreateEventWithCategoryAsync).
            var organiser = await LoggedInClientAsync("organiser.enrol4@test.com", UserRoles.Organiser);
            var categoryId = await CreateEventWithCategoryAsync(organiser);

            var p1 = await LoggedInClientAsync("participant.enrol4a@test.com", UserRoles.Participant);
            var p2 = await LoggedInClientAsync("participant.enrol4b@test.com", UserRoles.Participant);
            var p3 = await LoggedInClientAsync("participant.enrol4c@test.com", UserRoles.Participant);

            await p1.PostJsonAsync($"/api/categories/{categoryId}/enrolments", new { });
            await p2.PostJsonAsync($"/api/categories/{categoryId}/enrolments", new { });
            var thirdResponse = await p3.PostJsonAsync($"/api/categories/{categoryId}/enrolments", new { });

            Assert.Equal(HttpStatusCode.Conflict, thirdResponse.StatusCode);
        }
    }
}
