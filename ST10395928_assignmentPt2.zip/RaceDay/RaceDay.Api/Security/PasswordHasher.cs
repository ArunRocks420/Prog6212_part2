using System.Security.Cryptography;

namespace RaceDay.Api.Security
{
    /// <summary>
    /// Hashes and verifies passwords using PBKDF2-SHA256, built into .NET
    /// (System.Security.Cryptography.Rfc2898DeriveBytes) - no extra NuGet
    /// package required. Satisfies the brief's "password must be hashed and
    /// stored, never in its original form" requirement.
    ///
    /// Stored format: {iterations}.{base64(salt)}.{base64(hash)}
    /// </summary>
    public static class PasswordHasher
    {
        private const int SaltSize = 16;     // 128-bit salt
        private const int HashSize = 32;     // 256-bit derived key
        private const int Iterations = 100_000;

        public static string Hash(string password)
        {
            byte[] salt = RandomNumberGenerator.GetBytes(SaltSize);
            byte[] hash = Rfc2898DeriveBytes.Pbkdf2(
                password, salt, Iterations, HashAlgorithmName.SHA256, HashSize);

            return $"{Iterations}.{Convert.ToBase64String(salt)}.{Convert.ToBase64String(hash)}";
        }

        public static bool Verify(string password, string storedHash)
        {
            var parts = storedHash.Split('.', 3);
            if (parts.Length != 3) return false;

            int iterations = int.Parse(parts[0]);
            byte[] salt = Convert.FromBase64String(parts[1]);
            byte[] expectedHash = Convert.FromBase64String(parts[2]);

            byte[] actualHash = Rfc2898DeriveBytes.Pbkdf2(
                password, salt, iterations, HashAlgorithmName.SHA256, expectedHash.Length);

            return CryptographicOperations.FixedTimeEquals(actualHash, expectedHash);
        }
    }
}
