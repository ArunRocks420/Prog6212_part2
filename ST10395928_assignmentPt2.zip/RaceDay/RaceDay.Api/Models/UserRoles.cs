namespace RaceDay.Api.Models
{
    /// <summary>
    /// The two roles supported by the RaceDay system. Stored as plain strings
    /// in the database (matches the Part 1 SQL script's CHECK constraint) rather
    /// than an int-backed enum, so the values are readable directly in the DB.
    /// </summary>
    public static class UserRoles
    {
        public const string Organiser = "Organiser";
        public const string Participant = "Participant";

        public static bool IsValid(string? role) =>
            role == Organiser || role == Participant;
    }
}
