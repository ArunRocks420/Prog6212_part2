namespace RaceDay.Api.Models
{
    /// <summary>
    /// An age- or distance-based category within an Event (e.g. "Under 20",
    /// "Senior", "10km", "21km"), as required by the Functional Requirements.
    /// </summary>
    public class Category
    {
        public int CategoryId { get; set; }

        public int EventId { get; set; }
        public Event? Event { get; set; }

        /// <summary>Optional - a category does not have to be tied to a specific route.</summary>
        public int? RouteId { get; set; }
        public RaceRoute? Route { get; set; }

        public string CategoryName { get; set; } = string.Empty;

        /// <summary>Nullable because age-based categories (e.g. "Under 20") may not have a fixed distance.</summary>
        public decimal? DistanceKM { get; set; }

        public decimal EntryFee { get; set; }
        public int MaxParticipants { get; set; } = 100;

        public ICollection<Enrolment> Enrolments { get; set; } = new List<Enrolment>();
    }
}
