namespace RaceDay.Api.Models
{
    /// <summary>
    /// The type of road event. Required by the Part 2 Functional Requirements
    /// ("event type: run, walk, or cycle"). Stored as a string in the database
    /// via an EF Core value conversion (see RaceDayDbContext).
    /// </summary>
    public enum EventType
    {
        Run,
        Walk,
        Cycle
    }
}
