namespace RaceDay.Api.Models
{
    /// <summary>
    /// The finish time/position captured by an Organiser for a participant's
    /// Enrolment after the event. One-to-one with Enrolment.
    /// </summary>
    public class Result
    {
        public int ResultId { get; set; }

        public int EnrolmentId { get; set; }
        public Enrolment? Enrolment { get; set; }

        public TimeSpan? FinishTime { get; set; }
        public int? Position { get; set; }

        /// <summary>Finished, DNF (did not finish), or DQ (disqualified).</summary>
        public string Status { get; set; } = "Finished";
    }
}
