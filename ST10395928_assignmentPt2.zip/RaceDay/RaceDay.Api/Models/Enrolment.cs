namespace RaceDay.Api.Models
{
    /// <summary>
    /// Links a Participant to a Category they have entered. This is the junction
    /// table that resolves the many-to-many relationship between Users and
    /// Categories (see Part 1 ERD notes).
    /// </summary>
    public class Enrolment
    {
        public int EnrolmentId { get; set; }

        public int ParticipantId { get; set; }
        public User? Participant { get; set; }

        public int CategoryId { get; set; }
        public Category? Category { get; set; }

        public string BibNumber { get; set; } = string.Empty;
        public DateTime EnrolmentDate { get; set; } = DateTime.UtcNow;

        /// <summary>Confirmed, Cancelled, or Waitlisted.</summary>
        public string Status { get; set; } = "Confirmed";

        public Result? Result { get; set; }
    }
}
