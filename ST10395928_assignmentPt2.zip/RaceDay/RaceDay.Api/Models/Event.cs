namespace RaceDay.Api.Models
{
    /// <summary>
    /// A race-day event (e.g. a marathon or cycle tour), owned by an Organiser.
    /// Distance and EventType were added in Part 2 to satisfy the Functional
    /// Requirements; they were not present in the original Part 1 ERD/SQL script.
    /// See README.md "Deviations from Part 1" for the explanation required by the brief.
    /// </summary>
    public class Event
    {
        public int EventId { get; set; }

        public int OrganiserId { get; set; }
        public User? Organiser { get; set; }

        public string EventName { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public DateTime EventDate { get; set; }
        public string Location { get; set; } = string.Empty;

        /// <summary>Headline distance for the event, in kilometres (added in Part 2).</summary>
        public decimal Distance { get; set; }

        /// <summary>Run, Walk, or Cycle (added in Part 2).</summary>
        public EventType EventType { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        public ICollection<Category> Categories { get; set; } = new List<Category>();
    }
}
