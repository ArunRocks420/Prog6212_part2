namespace RaceDay.Api.Models
{
    /// <summary>
    /// A reusable course definition (distance, elevation, start/end points).
    /// Maps to the "Routes" table in the Part 1 ERD/SQL script. Named RaceRoute
    /// in code (table name is still "Routes") to avoid colliding with
    /// ASP.NET Core's own Route/Routing types.
    /// </summary>
    public class RaceRoute
    {
        public int RouteId { get; set; }

        public string RouteName { get; set; } = string.Empty;
        public decimal DistanceKM { get; set; }
        public decimal ElevationGainM { get; set; }
        public string StartLocation { get; set; } = string.Empty;
        public string EndLocation { get; set; } = string.Empty;
        public string? MapUrl { get; set; }

        public ICollection<Category> Categories { get; set; } = new List<Category>();
    }
}
