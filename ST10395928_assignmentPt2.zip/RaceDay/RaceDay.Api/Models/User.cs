namespace RaceDay.Api.Models
{
    /// <summary>
    /// A registered user of RaceDay. The same table holds both Organisers and
    /// Participants, distinguished by Role (see UserRoles) - this matches the
    /// Part 1 ERD and SQL script.
    /// </summary>
    public class User
    {
        public int UserId { get; set; }

        public string FirstName { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;

        public string Email { get; set; } = string.Empty;

        /// <summary>PBKDF2 hash of the password. The plain password is never stored.</summary>
        public string PasswordHash { get; set; } = string.Empty;

        public string? PhoneNumber { get; set; }

        public string Role { get; set; } = UserRoles.Participant;

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        // Navigation properties
        public ICollection<Event> OrganisedEvents { get; set; } = new List<Event>();
        public ICollection<Enrolment> Enrolments { get; set; } = new List<Enrolment>();
    }
}
