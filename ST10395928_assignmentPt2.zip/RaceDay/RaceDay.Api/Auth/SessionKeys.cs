namespace RaceDay.Api.Auth
{
    /// <summary>Keys used to read/write ASP.NET Core Session state after login.</summary>
    public static class SessionKeys
    {
        public const string UserId = "UserId";
        public const string Role = "Role";
        public const string FullName = "FullName";
    }
}
