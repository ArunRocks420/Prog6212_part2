using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace RaceDay.Api.Auth
{
    /// <summary>
    /// Blocks the request with 401 if there is no session, or 403 if the
    /// session's role does not match the one required. This is how
    /// "Organiser functionality must not be accessible to a Participant and
    /// vice versa" is enforced.
    /// </summary>
    public class RequireRoleAttribute : ActionFilterAttribute
    {
        private readonly string _requiredRole;

        public RequireRoleAttribute(string requiredRole)
        {
            _requiredRole = requiredRole;
        }

        public override void OnActionExecuting(ActionExecutingContext context)
        {
            var userId = context.HttpContext.Session.GetInt32(SessionKeys.UserId);
            if (userId is null)
            {
                context.Result = new UnauthorizedObjectResult(new
                {
                    message = "You must be logged in to access this resource."
                });
                return;
            }

            var role = context.HttpContext.Session.GetString(SessionKeys.Role);
            if (role != _requiredRole)
            {
                context.Result = new ObjectResult(new
                {
                    message = $"This action requires the '{_requiredRole}' role."
                })
                { StatusCode = StatusCodes.Status403Forbidden };
            }
        }
    }
}
