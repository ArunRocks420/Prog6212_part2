using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace RaceDay.Api.Auth
{
    /// <summary>
    /// Blocks the request with 401 Unauthorized unless the caller has a valid
    /// RaceDay session (i.e. they have logged in via POST /api/auth/login).
    /// This is how "Non-public areas of the API must only be accessible to
    /// authenticated users" is enforced, using session state rather than JWT.
    /// </summary>
    public class RequireSessionAuthAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            var userId = context.HttpContext.Session.GetInt32(SessionKeys.UserId);
            if (userId is null)
            {
                context.Result = new UnauthorizedObjectResult(new
                {
                    message = "You must be logged in to access this resource."
                });
            }
        }
    }
}
