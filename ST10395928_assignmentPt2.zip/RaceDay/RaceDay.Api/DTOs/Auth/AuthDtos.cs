using System.ComponentModel.DataAnnotations;

namespace RaceDay.Api.DTOs.Auth
{
    /// <summary>Body for POST /api/auth/register.</summary>
    public class RegisterRequest
    {
        [Required, MaxLength(50)]
        public string FirstName { get; set; } = string.Empty;

        [Required, MaxLength(50)]
        public string LastName { get; set; } = string.Empty;

        [Required, EmailAddress, MaxLength(100)]
        public string Email { get; set; } = string.Empty;

        [Required, MinLength(8)]
        public string Password { get; set; } = string.Empty;

        [MaxLength(20)]
        public string? PhoneNumber { get; set; }

        /// <summary>Must be "Organiser" or "Participant".</summary>
        [Required]
        public string Role { get; set; } = string.Empty;
    }

    /// <summary>Body for POST /api/auth/login.</summary>
    public class LoginRequest
    {
        [Required, EmailAddress]
        public string Email { get; set; } = string.Empty;

        [Required]
        public string Password { get; set; } = string.Empty;
    }

    /// <summary>Returned by register/login - never includes the password or its hash.</summary>
    public class AuthResponse
    {
        public int UserId { get; set; }
        public string FirstName { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string Role { get; set; } = string.Empty;
    }
}
