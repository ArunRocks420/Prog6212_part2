using System.ComponentModel.DataAnnotations;

namespace RaceDay.Api.DTOs.Results
{
    public class ResultDto
    {
        public int ResultId { get; set; }
        public int EnrolmentId { get; set; }
        public string ParticipantName { get; set; } = string.Empty;
        public string BibNumber { get; set; } = string.Empty;
        public TimeSpan? FinishTime { get; set; }
        public int? Position { get; set; }
        public string Status { get; set; } = string.Empty;
    }

    /// <summary>Body for POST /api/enrolments/{enrolmentId}/result and PUT /api/results/{id}.</summary>
    public class CaptureResultRequest
    {
        public TimeSpan? FinishTime { get; set; }
        public int? Position { get; set; }

        [Required, MaxLength(20)]
        public string Status { get; set; } = "Finished";
    }
}
