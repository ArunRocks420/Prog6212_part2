using System.ComponentModel.DataAnnotations;

namespace RaceDay.Api.DTOs.Categories
{
    public class CategoryDto
    {
        public int CategoryId { get; set; }
        public int EventId { get; set; }
        public int? RouteId { get; set; }
        public string CategoryName { get; set; } = string.Empty;
        public decimal? DistanceKM { get; set; }
        public decimal EntryFee { get; set; }
        public int MaxParticipants { get; set; }
        public int EnrolledCount { get; set; }
    }

    /// <summary>Body for POST /api/events/{eventId}/categories.</summary>
    public class CreateCategoryRequest
    {
        [Required, MaxLength(50)]
        public string CategoryName { get; set; } = string.Empty;

        public decimal? DistanceKM { get; set; }

        [Range(0, 100000)]
        public decimal EntryFee { get; set; }

        [Range(1, 100000)]
        public int MaxParticipants { get; set; } = 100;

        public int? RouteId { get; set; }
    }

    /// <summary>Body for PUT /api/categories/{id}.</summary>
    public class UpdateCategoryRequest : CreateCategoryRequest { }
}
