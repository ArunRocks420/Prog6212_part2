using System.ComponentModel.DataAnnotations;

namespace RaceDay.Api.DTOs.Routes
{
    public class RouteDto
    {
        public int RouteId { get; set; }
        public string RouteName { get; set; } = string.Empty;
        public decimal DistanceKM { get; set; }
        public decimal ElevationGainM { get; set; }
        public string StartLocation { get; set; } = string.Empty;
        public string EndLocation { get; set; } = string.Empty;
        public string? MapUrl { get; set; }
    }

    /// <summary>Body for POST /api/routes.</summary>
    public class CreateRouteRequest
    {
        [Required, MaxLength(100)]
        public string RouteName { get; set; } = string.Empty;

        [Range(0.1, 1000)]
        public decimal DistanceKM { get; set; }

        [Range(0, 10000)]
        public decimal ElevationGainM { get; set; }

        [Required, MaxLength(150)]
        public string StartLocation { get; set; } = string.Empty;

        [Required, MaxLength(150)]
        public string EndLocation { get; set; } = string.Empty;

        [MaxLength(255)]
        public string? MapUrl { get; set; }
    }
}
