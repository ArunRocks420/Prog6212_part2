using System.ComponentModel.DataAnnotations;

namespace RaceDay.Api.DTOs.Users
{
    /// <summary>Returned by GET /api/users/me.</summary>
    public class UserProfileDto
    {
        public int UserId { get; set; }
        public string FirstName { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string? PhoneNumber { get; set; }
        public string Role { get; set; } = string.Empty;
        public DateTime CreatedAt { get; set; }
    }

    /// <summary>Body for PUT /api/users/me.</summary>
    public class UpdateProfileRequest
    {
        [Required, MaxLength(50)]
        public string FirstName { get; set; } = string.Empty;

        [Required, MaxLength(50)]
        public string LastName { get; set; } = string.Empty;

        [MaxLength(20)]
        public string? PhoneNumber { get; set; }
    }

    /// <summary>One row of a participant's history, returned by GET /api/users/{id}/history.</summary>
    public class PerformanceHistoryItemDto
    {
        public int EventId { get; set; }
        public string EventName { get; set; } = string.Empty;
        public DateTime EventDate { get; set; }
        public string CategoryName { get; set; } = string.Empty;
        public string BibNumber { get; set; } = string.Empty;
        public TimeSpan? FinishTime { get; set; }
        public int? Position { get; set; }
        public string? ResultStatus { get; set; }
    }
}
