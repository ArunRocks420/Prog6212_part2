using System.ComponentModel.DataAnnotations;
using RaceDay.Api.Models;

namespace RaceDay.Api.DTOs.Events
{
    public class EventDto
    {
        public int EventId { get; set; }
        public int OrganiserId { get; set; }
        public string OrganiserName { get; set; } = string.Empty;
        public string EventName { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public DateTime EventDate { get; set; }
        public string Location { get; set; } = string.Empty;
        public decimal Distance { get; set; }
        public string EventType { get; set; } = string.Empty;
        public DateTime CreatedAt { get; set; }
        public int CategoryCount { get; set; }
    }

    /// <summary>Body for POST /api/events.</summary>
    public class CreateEventRequest
    {
        [Required, MaxLength(100)]
        public string EventName { get; set; } = string.Empty;

        [Required]
        public string Description { get; set; } = string.Empty;

        [Required]
        public DateTime EventDate { get; set; }

        [Required, MaxLength(150)]
        public string Location { get; set; } = string.Empty;

        [Range(0.1, 1000)]
        public decimal Distance { get; set; }

        [Required]
        public EventType EventType { get; set; }
    }

    /// <summary>Body for PUT /api/events/{id}.</summary>
    public class UpdateEventRequest : CreateEventRequest { }
}
