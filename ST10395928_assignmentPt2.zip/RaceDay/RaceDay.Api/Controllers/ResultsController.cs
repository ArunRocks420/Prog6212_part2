using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Auth;
using RaceDay.Api.Data;
using RaceDay.Api.DTOs.Results;
using RaceDay.Api.Models;

namespace RaceDay.Api.Controllers
{
    /// <summary>
    /// Captures and exposes race results. Only the Organiser who owns the event
    /// may capture/correct a result. A leaderboard per event is public.
    /// Participants can view their own results.
    /// </summary>
    [ApiController]
    public class ResultsController : ControllerBase
    {
        private readonly RaceDayDbContext _context;

        public ResultsController(RaceDayDbContext context)
        {
            _context = context;
        }

        /// <summary>Captures the finish time/position for a participant after the race. Owner only.</summary>
        [HttpPost("api/enrolments/{enrolmentId}/result")]
        [RequireRole(UserRoles.Organiser)]
        public async Task<ActionResult<ResultDto>> CaptureResult(int enrolmentId, CaptureResultRequest request)
        {
            var organiserId = HttpContext.Session.GetInt32(SessionKeys.UserId)!.Value;

            var enrolment = await _context.Enrolments
                .Include(e => e.Category).ThenInclude(c => c!.Event)
                .Include(e => e.Participant)
                .Include(e => e.Result)
                .FirstOrDefaultAsync(e => e.EnrolmentId == enrolmentId);

            if (enrolment is null) return NotFound(new { message = "Enrolment not found." });
            if (enrolment.Category!.Event!.OrganiserId != organiserId)
                return StatusCode(StatusCodes.Status403Forbidden,
                    new { message = "You may only capture results for events you organise." });

            if (enrolment.Result is not null)
                return Conflict(new { message = "A result has already been captured for this enrolment. Use PUT to update it." });

            var result = new Result
            {
                EnrolmentId = enrolmentId,
                FinishTime = request.FinishTime,
                Position = request.Position,
                Status = request.Status
            };

            _context.Results.Add(result);
            await _context.SaveChangesAsync();

            return StatusCode(StatusCodes.Status201Created, ToDto(result, enrolment));
        }

        /// <summary>Corrects a previously captured result. Owner only.</summary>
        [HttpPut("api/results/{id}")]
        [RequireRole(UserRoles.Organiser)]
        public async Task<ActionResult<ResultDto>> UpdateResult(int id, CaptureResultRequest request)
        {
            var organiserId = HttpContext.Session.GetInt32(SessionKeys.UserId)!.Value;

            var result = await _context.Results
                .Include(r => r.Enrolment).ThenInclude(e => e!.Category).ThenInclude(c => c!.Event)
                .Include(r => r.Enrolment).ThenInclude(e => e!.Participant)
                .FirstOrDefaultAsync(r => r.ResultId == id);

            if (result is null) return NotFound();
            if (result.Enrolment!.Category!.Event!.OrganiserId != organiserId)
                return StatusCode(StatusCodes.Status403Forbidden,
                    new { message = "You may only update results for events you organise." });

            result.FinishTime = request.FinishTime;
            result.Position = request.Position;
            result.Status = request.Status;

            await _context.SaveChangesAsync();
            return Ok(ToDto(result, result.Enrolment));
        }

        /// <summary>Retrieves the full results list (leaderboard) for an event. Public.</summary>
        [HttpGet("api/events/{eventId}/results")]
        public async Task<ActionResult<List<ResultDto>>> GetResultsForEvent(int eventId)
        {
            var eventExists = await _context.Events.AnyAsync(e => e.EventId == eventId);
            if (!eventExists) return NotFound(new { message = "Event not found." });

            var results = await _context.Results
                .Include(r => r.Enrolment).ThenInclude(e => e!.Category)
                .Include(r => r.Enrolment).ThenInclude(e => e!.Participant)
                .Where(r => r.Enrolment!.Category!.EventId == eventId)
                .OrderBy(r => r.Position)
                .Select(r => ToDto(r, r.Enrolment!))
                .ToListAsync();

            return Ok(results);
        }

        /// <summary>Retrieves the logged-in participant's own results across all events.</summary>
        [HttpGet("api/users/me/results")]
        [RequireRole(UserRoles.Participant)]
        public async Task<ActionResult<List<ResultDto>>> GetMyResults()
        {
            var participantId = HttpContext.Session.GetInt32(SessionKeys.UserId)!.Value;

            var results = await _context.Results
                .Include(r => r.Enrolment).ThenInclude(e => e!.Category)
                .Include(r => r.Enrolment).ThenInclude(e => e!.Participant)
                .Where(r => r.Enrolment!.ParticipantId == participantId)
                .Select(r => ToDto(r, r.Enrolment!))
                .ToListAsync();

            return Ok(results);
        }

        private static ResultDto ToDto(Result r, Enrolment enrolment) => new()
        {
            ResultId = r.ResultId,
            EnrolmentId = r.EnrolmentId,
            ParticipantName = enrolment.Participant is not null
                ? $"{enrolment.Participant.FirstName} {enrolment.Participant.LastName}" : string.Empty,
            BibNumber = enrolment.BibNumber,
            FinishTime = r.FinishTime,
            Position = r.Position,
            Status = r.Status
        };
    }
}
