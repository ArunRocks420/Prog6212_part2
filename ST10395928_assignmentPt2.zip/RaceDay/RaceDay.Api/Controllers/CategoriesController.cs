using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Auth;
using RaceDay.Api.Data;
using RaceDay.Api.DTOs.Categories;
using RaceDay.Api.Models;

namespace RaceDay.Api.Controllers
{
    /// <summary>
    /// Category management (age- or distance-based categories within an event).
    /// Viewing is public; creating/updating/deleting is restricted to the
    /// Organiser who owns the parent event.
    /// </summary>
    [ApiController]
    public class CategoriesController : ControllerBase
    {
        private readonly RaceDayDbContext _context;

        public CategoriesController(RaceDayDbContext context)
        {
            _context = context;
        }

        /// <summary>Lists all categories for a specific event.</summary>
        [HttpGet("api/events/{eventId}/categories")]
        public async Task<ActionResult<List<CategoryDto>>> GetCategoriesForEvent(int eventId)
        {
            var eventExists = await _context.Events.AnyAsync(e => e.EventId == eventId);
            if (!eventExists) return NotFound(new { message = "Event not found." });

            var categories = await _context.Categories
                .Where(c => c.EventId == eventId)
                .Include(c => c.Enrolments)
                .Select(c => ToDto(c))
                .ToListAsync();

            return Ok(categories);
        }

        /// <summary>Adds a new category to an event. Owner only.</summary>
        [HttpPost("api/events/{eventId}/categories")]
        [RequireRole(UserRoles.Organiser)]
        public async Task<ActionResult<CategoryDto>> CreateCategory(int eventId, CreateCategoryRequest request)
        {
            var organiserId = HttpContext.Session.GetInt32(SessionKeys.UserId)!.Value;
            var ev = await _context.Events.FindAsync(eventId);
            if (ev is null) return NotFound(new { message = "Event not found." });
            if (ev.OrganiserId != organiserId)
                return StatusCode(StatusCodes.Status403Forbidden,
                    new { message = "You may only add categories to events you organise." });

            if (request.RouteId is not null && !await _context.Routes.AnyAsync(r => r.RouteId == request.RouteId))
                return BadRequest(new { message = "RouteId does not exist." });

            var category = new Category
            {
                EventId = eventId,
                RouteId = request.RouteId,
                CategoryName = request.CategoryName,
                DistanceKM = request.DistanceKM,
                EntryFee = request.EntryFee,
                MaxParticipants = request.MaxParticipants
            };

            _context.Categories.Add(category);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetCategoriesForEvent), new { eventId }, ToDto(category));
        }

        /// <summary>Updates an existing category. Owner only.</summary>
        [HttpPut("api/categories/{id}")]
        [RequireRole(UserRoles.Organiser)]
        public async Task<ActionResult<CategoryDto>> UpdateCategory(int id, UpdateCategoryRequest request)
        {
            var organiserId = HttpContext.Session.GetInt32(SessionKeys.UserId)!.Value;
            var category = await _context.Categories.Include(c => c.Event).FirstOrDefaultAsync(c => c.CategoryId == id);

            if (category is null) return NotFound();
            if (category.Event!.OrganiserId != organiserId)
                return StatusCode(StatusCodes.Status403Forbidden,
                    new { message = "You may only update categories for events you organise." });

            category.CategoryName = request.CategoryName;
            category.DistanceKM = request.DistanceKM;
            category.EntryFee = request.EntryFee;
            category.MaxParticipants = request.MaxParticipants;
            category.RouteId = request.RouteId;

            await _context.SaveChangesAsync();
            return Ok(ToDto(category));
        }

        /// <summary>Removes a category from an event. Owner only.</summary>
        [HttpDelete("api/categories/{id}")]
        [RequireRole(UserRoles.Organiser)]
        public async Task<IActionResult> DeleteCategory(int id)
        {
            var organiserId = HttpContext.Session.GetInt32(SessionKeys.UserId)!.Value;
            var category = await _context.Categories.Include(c => c.Event).FirstOrDefaultAsync(c => c.CategoryId == id);

            if (category is null) return NotFound();
            if (category.Event!.OrganiserId != organiserId)
                return StatusCode(StatusCodes.Status403Forbidden,
                    new { message = "You may only delete categories for events you organise." });

            _context.Categories.Remove(category);
            await _context.SaveChangesAsync();
            return NoContent();
        }

        private static CategoryDto ToDto(Category c) => new()
        {
            CategoryId = c.CategoryId,
            EventId = c.EventId,
            RouteId = c.RouteId,
            CategoryName = c.CategoryName,
            DistanceKM = c.DistanceKM,
            EntryFee = c.EntryFee,
            MaxParticipants = c.MaxParticipants,
            EnrolledCount = c.Enrolments?.Count ?? 0
        };
    }
}
