using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Auth;
using RaceDay.Api.Data;
using RaceDay.Api.DTOs.Events;
using RaceDay.Api.Models;

namespace RaceDay.Api.Controllers
{
    /// <summary>
    /// Event management. Browsing is public (per the brief: "Both roles must be
    /// able to view events"). Creating, updating and deleting are restricted to
    /// the Organiser who owns the event.
    /// </summary>
    [ApiController]
    [Route("api/events")]
    public class EventsController : ControllerBase
    {
        private readonly RaceDayDbContext _context;

        public EventsController(RaceDayDbContext context)
        {
            _context = context;
        }

        /// <summary>Lists all events, optionally filtered by date range or location.</summary>
        [HttpGet]
        public async Task<ActionResult<List<EventDto>>> GetEvents(
            [FromQuery] DateTime? fromDate, [FromQuery] string? location)
        {
            var query = _context.Events.Include(e => e.Organiser).Include(e => e.Categories).AsQueryable();

            if (fromDate is not null)
                query = query.Where(e => e.EventDate >= fromDate);

            if (!string.IsNullOrWhiteSpace(location))
                query = query.Where(e => e.Location.Contains(location));

            var events = await query.OrderBy(e => e.EventDate).Select(e => ToDto(e)).ToListAsync();
            return Ok(events);
        }

        /// <summary>Retrieves full details for a single event.</summary>
        [HttpGet("{id}")]
        public async Task<ActionResult<EventDto>> GetEvent(int id)
        {
            var ev = await _context.Events.Include(e => e.Organiser).Include(e => e.Categories)
                .FirstOrDefaultAsync(e => e.EventId == id);

            if (ev is null) return NotFound();
            return Ok(ToDto(ev));
        }

        /// <summary>Creates a new event, owned by the logged-in Organiser.</summary>
        [HttpPost]
        [RequireRole(UserRoles.Organiser)]
        public async Task<ActionResult<EventDto>> CreateEvent(CreateEventRequest request)
        {
            var organiserId = HttpContext.Session.GetInt32(SessionKeys.UserId)!.Value;

            var ev = new Event
            {
                OrganiserId = organiserId,
                EventName = request.EventName,
                Description = request.Description,
                EventDate = request.EventDate,
                Location = request.Location,
                Distance = request.Distance,
                EventType = request.EventType
            };

            _context.Events.Add(ev);
            await _context.SaveChangesAsync();

            await _context.Entry(ev).Reference(e => e.Organiser).LoadAsync();
            return CreatedAtAction(nameof(GetEvent), new { id = ev.EventId }, ToDto(ev));
        }

        /// <summary>Updates an event. Only the Organiser who owns it may update it.</summary>
        [HttpPut("{id}")]
        [RequireRole(UserRoles.Organiser)]
        public async Task<ActionResult<EventDto>> UpdateEvent(int id, UpdateEventRequest request)
        {
            var organiserId = HttpContext.Session.GetInt32(SessionKeys.UserId)!.Value;
            var ev = await _context.Events.Include(e => e.Organiser).FirstOrDefaultAsync(e => e.EventId == id);

            if (ev is null) return NotFound();
            if (ev.OrganiserId != organiserId)
                return StatusCode(StatusCodes.Status403Forbidden,
                    new { message = "You may only update events you organise." });

            ev.EventName = request.EventName;
            ev.Description = request.Description;
            ev.EventDate = request.EventDate;
            ev.Location = request.Location;
            ev.Distance = request.Distance;
            ev.EventType = request.EventType;

            await _context.SaveChangesAsync();
            return Ok(ToDto(ev));
        }

        /// <summary>Deletes an event (and its categories/enrolments). Owner only.</summary>
        [HttpDelete("{id}")]
        [RequireRole(UserRoles.Organiser)]
        public async Task<IActionResult> DeleteEvent(int id)
        {
            var organiserId = HttpContext.Session.GetInt32(SessionKeys.UserId)!.Value;
            var ev = await _context.Events.FindAsync(id);

            if (ev is null) return NotFound();
            if (ev.OrganiserId != organiserId)
                return StatusCode(StatusCodes.Status403Forbidden,
                    new { message = "You may only delete events you organise." });

            _context.Events.Remove(ev);
            await _context.SaveChangesAsync();
            return NoContent();
        }

        private static EventDto ToDto(Event e) => new()
        {
            EventId = e.EventId,
            OrganiserId = e.OrganiserId,
            OrganiserName = e.Organiser is not null ? $"{e.Organiser.FirstName} {e.Organiser.LastName}" : string.Empty,
            EventName = e.EventName,
            Description = e.Description,
            EventDate = e.EventDate,
            Location = e.Location,
            Distance = e.Distance,
            EventType = e.EventType.ToString(),
            CreatedAt = e.CreatedAt,
            CategoryCount = e.Categories?.Count ?? 0
        };
    }
}
