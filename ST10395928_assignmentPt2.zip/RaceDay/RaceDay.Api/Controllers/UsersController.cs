using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Auth;
using RaceDay.Api.Data;
using RaceDay.Api.DTOs.Users;
using RaceDay.Api.Models;

namespace RaceDay.Api.Controllers
{
    /// <summary>Profile management for the logged-in user, and performance history.</summary>
    [ApiController]
    [Route("api/users")]
    [RequireSessionAuth]
    public class UsersController : ControllerBase
    {
        private readonly RaceDayDbContext _context;

        public UsersController(RaceDayDbContext context)
        {
            _context = context;
        }

        /// <summary>Returns the profile of the currently logged-in user.</summary>
        [HttpGet("me")]
        public async Task<ActionResult<UserProfileDto>> GetMyProfile()
        {
            var userId = HttpContext.Session.GetInt32(SessionKeys.UserId)!.Value;
            var user = await _context.Users.FindAsync(userId);
            if (user is null) return NotFound();

            return Ok(ToProfileDto(user));
        }

        /// <summary>Updates the current user's own profile details.</summary>
        [HttpPut("me")]
        public async Task<ActionResult<UserProfileDto>> UpdateMyProfile(UpdateProfileRequest request)
        {
            var userId = HttpContext.Session.GetInt32(SessionKeys.UserId)!.Value;
            var user = await _context.Users.FindAsync(userId);
            if (user is null) return NotFound();

            user.FirstName = request.FirstName;
            user.LastName = request.LastName;
            user.PhoneNumber = request.PhoneNumber;

            await _context.SaveChangesAsync();
            return Ok(ToProfileDto(user));
        }

        /// <summary>
        /// Returns a participant's personal performance history (all past
        /// enrolments and their results). A Participant may only view their own
        /// history; an Organiser may view any participant's history.
        /// </summary>
        [HttpGet("{id}/history")]
        public async Task<ActionResult<List<PerformanceHistoryItemDto>>> GetHistory(int id)
        {
            var sessionUserId = HttpContext.Session.GetInt32(SessionKeys.UserId)!.Value;
            var sessionRole = HttpContext.Session.GetString(SessionKeys.Role);

            if (sessionRole == UserRoles.Participant && sessionUserId != id)
                return StatusCode(StatusCodes.Status403Forbidden,
                    new { message = "Participants may only view their own performance history." });

            var history = await _context.Enrolments
                .Where(e => e.ParticipantId == id)
                .Include(e => e.Category).ThenInclude(c => c!.Event)
                .Include(e => e.Result)
                .OrderByDescending(e => e.Category!.Event!.EventDate)
                .Select(e => new PerformanceHistoryItemDto
                {
                    EventId = e.Category!.Event!.EventId,
                    EventName = e.Category.Event.EventName,
                    EventDate = e.Category.Event.EventDate,
                    CategoryName = e.Category.CategoryName,
                    BibNumber = e.BibNumber,
                    FinishTime = e.Result != null ? e.Result.FinishTime : null,
                    Position = e.Result != null ? e.Result.Position : null,
                    ResultStatus = e.Result != null ? e.Result.Status : null
                })
                .ToListAsync();

            return Ok(history);
        }

        private static UserProfileDto ToProfileDto(User user) => new()
        {
            UserId = user.UserId,
            FirstName = user.FirstName,
            LastName = user.LastName,
            Email = user.Email,
            PhoneNumber = user.PhoneNumber,
            Role = user.Role,
            CreatedAt = user.CreatedAt
        };
    }
}
