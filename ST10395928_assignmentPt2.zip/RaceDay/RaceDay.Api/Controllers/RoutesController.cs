using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Auth;
using RaceDay.Api.Data;
using RaceDay.Api.DTOs.Routes;
using RaceDay.Api.Models;

namespace RaceDay.Api.Controllers
{
    /// <summary>
    /// Route (course) details - distance, elevation, start/end points - used by
    /// Categories and surfaced to Participants for race-day preparation.
    /// </summary>
    [ApiController]
    [Route("api/routes")]
    public class RoutesController : ControllerBase
    {
        private readonly RaceDayDbContext _context;

        public RoutesController(RaceDayDbContext context)
        {
            _context = context;
        }

        /// <summary>Retrieves route details for race-day preparation. Public.</summary>
        [HttpGet("{id}")]
        public async Task<ActionResult<RouteDto>> GetRoute(int id)
        {
            var route = await _context.Routes.FindAsync(id);
            if (route is null) return NotFound();
            return Ok(ToDto(route));
        }

        /// <summary>Creates a new route that can be attached to one or more categories.</summary>
        [HttpPost]
        [RequireRole(UserRoles.Organiser)]
        public async Task<ActionResult<RouteDto>> CreateRoute(CreateRouteRequest request)
        {
            var route = new RaceRoute
            {
                RouteName = request.RouteName,
                DistanceKM = request.DistanceKM,
                ElevationGainM = request.ElevationGainM,
                StartLocation = request.StartLocation,
                EndLocation = request.EndLocation,
                MapUrl = request.MapUrl
            };

            _context.Routes.Add(route);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetRoute), new { id = route.RouteId }, ToDto(route));
        }

        private static RouteDto ToDto(RaceRoute r) => new()
        {
            RouteId = r.RouteId,
            RouteName = r.RouteName,
            DistanceKM = r.DistanceKM,
            ElevationGainM = r.ElevationGainM,
            StartLocation = r.StartLocation,
            EndLocation = r.EndLocation,
            MapUrl = r.MapUrl
        };
    }
}
