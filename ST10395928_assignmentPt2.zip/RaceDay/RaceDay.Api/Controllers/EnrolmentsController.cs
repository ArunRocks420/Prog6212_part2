using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Auth;
using RaceDay.Api.Data;
using RaceDay.Api.DTOs.Enrolments;
using RaceDay.Api.Models;

namespace RaceDay.Api.Controllers
{
    /// <summary>
    /// Event enrolments - links a Participant to a Category. Entering an event is
    /// Participant-only; viewing a category's full roster is Organiser-only
    /// (and restricted to the event they own).
    /// </summary>
    [ApiController]
    public class EnrolmentsController : ControllerBase
    {
        private readonly RaceDayDbContext _context;

        public EnrolmentsController(RaceDayDbContext context)
        {
            _context = context;
        }

        /// <summary>
        /// Enters the logged-in participant into a category. Records the link
        /// between Participant, Event and Category, and assigns a bib number.
        /// </summary>
        [HttpPost("api/categories/{categoryId}/enrolments")]
        [RequireRole(UserRoles.Participant)]
        public async Task<ActionResult<EnrolmentDto>> Enrol(int categoryId)
        {
            var participantId = HttpContext.Session.GetInt32(SessionKeys.UserId)!.Value;

            var category = await _context.Categories
                .Include(c => c.Event)
                .Include(c => c.Enrolments)
                .FirstOrDefaultAsync(c => c.CategoryId == categoryId);

            if (category is null) return NotFound(new { message = "Category not found." });

            if (category.Enrolments.Any(e => e.ParticipantId == participantId))
                return Conflict(new { message = "You are already enrolled in this category." });

            if (category.Enrolments.Count >= category.MaxParticipants)
                return Conflict(new { message = "This category is full." });

            var bibNumber = $"{category.CategoryId:D3}-{category.Enrolments.Count + 1:D4}";

            var enrolment = new Enrolment
            {
                ParticipantId = participantId,
                CategoryId = categoryId,
                BibNumber = bibNumber
            };

            _context.Enrolments.Add(enrolment);
            await _context.SaveChangesAsync();

            var participant = await _context.Users.FindAsync(participantId);

            return StatusCode(StatusCodes.Status201Created, new EnrolmentDto
            {
                EnrolmentId = enrolment.EnrolmentId,
                ParticipantId = participantId,
                ParticipantName = participant is not null ? $"{participant.FirstName} {participant.LastName}" : string.Empty,
                CategoryId = category.CategoryId,
                CategoryName = category.CategoryName,
                EventId = category.EventId,
                EventName = category.Event!.EventName,
                BibNumber = enrolment.BibNumber,
                EnrolmentDate = enrolment.EnrolmentDate,
                Status = enrolment.Status
            });
        }

        /// <summary>Lists all events/categories the logged-in participant is enrolled in.</summary>
        [HttpGet("api/users/me/enrolments")]
        [RequireRole(UserRoles.Participant)]
        public async Task<ActionResult<List<EnrolmentDto>>> GetMyEnrolments()
        {
            var participantId = HttpContext.Session.GetInt32(SessionKeys.UserId)!.Value;

            var enrolments = await _context.Enrolments
                .Where(e => e.ParticipantId == participantId)
                .Include(e => e.Category).ThenInclude(c => c!.Event)
                .Include(e => e.Participant)
                .Select(e => ToDto(e))
                .ToListAsync();

            return Ok(enrolments);
        }

        /// <summary>Lists all participants enrolled in a category. Restricted to the owning Organiser.</summary>
        [HttpGet("api/categories/{categoryId}/enrolments")]
        [RequireRole(UserRoles.Organiser)]
        public async Task<ActionResult<List<EnrolmentDto>>> GetEnrolmentsForCategory(int categoryId)
        {
            var organiserId = HttpContext.Session.GetInt32(SessionKeys.UserId)!.Value;

            var category = await _context.Categories.Include(c => c.Event)
                .FirstOrDefaultAsync(c => c.CategoryId == categoryId);

            if (category is null) return NotFound(new { message = "Category not found." });
            if (category.Event!.OrganiserId != organiserId)
                return StatusCode(StatusCodes.Status403Forbidden,
                    new { message = "You may only view enrolments for events you organise." });

            var enrolments = await _context.Enrolments
                .Where(e => e.CategoryId == categoryId)
                .Include(e => e.Category).ThenInclude(c => c!.Event)
                .Include(e => e.Participant)
                .Select(e => ToDto(e))
                .ToListAsync();

            return Ok(enrolments);
        }

        /// <summary>Cancels/withdraws an enrolment. The participant themselves or the owning Organiser may do this.</summary>
        [HttpDelete("api/enrolments/{id}")]
        [RequireSessionAuth]
        public async Task<IActionResult> CancelEnrolment(int id)
        {
            var sessionUserId = HttpContext.Session.GetInt32(SessionKeys.UserId)!.Value;
            var sessionRole = HttpContext.Session.GetString(SessionKeys.Role);

            var enrolment = await _context.Enrolments.Include(e => e.Category).ThenInclude(c => c!.Event)
                .FirstOrDefaultAsync(e => e.EnrolmentId == id);

            if (enrolment is null) return NotFound();

            var isOwnEnrolment = sessionRole == UserRoles.Participant && enrolment.ParticipantId == sessionUserId;
            var isOwningOrganiser = sessionRole == UserRoles.Organiser && enrolment.Category!.Event!.OrganiserId == sessionUserId;

            if (!isOwnEnrolment && !isOwningOrganiser)
                return StatusCode(StatusCodes.Status403Forbidden,
                    new { message = "You may only cancel your own enrolments or enrolments for events you organise." });

            _context.Enrolments.Remove(enrolment);
            await _context.SaveChangesAsync();
            return NoContent();
        }

        private static EnrolmentDto ToDto(Enrolment e) => new()
        {
            EnrolmentId = e.EnrolmentId,
            ParticipantId = e.ParticipantId,
            ParticipantName = e.Participant is not null ? $"{e.Participant.FirstName} {e.Participant.LastName}" : string.Empty,
            CategoryId = e.CategoryId,
            CategoryName = e.Category!.CategoryName,
            EventId = e.Category.EventId,
            EventName = e.Category.Event!.EventName,
            BibNumber = e.BibNumber,
            EnrolmentDate = e.EnrolmentDate,
            Status = e.Status
        };
    }
}
