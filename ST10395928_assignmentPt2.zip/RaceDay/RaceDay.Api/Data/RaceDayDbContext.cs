using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Models;

namespace RaceDay.Api.Data
{
    public class RaceDayDbContext : DbContext
    {
        public RaceDayDbContext(DbContextOptions<RaceDayDbContext> options) : base(options) { }

        public DbSet<User> Users => Set<User>();
        public DbSet<Event> Events => Set<Event>();
        public DbSet<RaceRoute> Routes => Set<RaceRoute>();
        public DbSet<Category> Categories => Set<Category>();
        public DbSet<Enrolment> Enrolments => Set<Enrolment>();
        public DbSet<Result> Results => Set<Result>();

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // ----- Users -----
            modelBuilder.Entity<User>(entity =>
            {
                entity.ToTable("Users");
                entity.HasIndex(u => u.Email).IsUnique();
                entity.Property(u => u.FirstName).HasMaxLength(50).IsRequired();
                entity.Property(u => u.LastName).HasMaxLength(50).IsRequired();
                entity.Property(u => u.Email).HasMaxLength(100).IsRequired();
                entity.Property(u => u.PasswordHash).HasMaxLength(255).IsRequired();
                entity.Property(u => u.PhoneNumber).HasMaxLength(20);
                entity.Property(u => u.Role).HasMaxLength(20).IsRequired();
            });

            // ----- Routes -----
            modelBuilder.Entity<RaceRoute>(entity =>
            {
                entity.ToTable("Routes");
                entity.Property(r => r.RouteName).HasMaxLength(100).IsRequired();
                entity.Property(r => r.DistanceKM).HasColumnType("decimal(5,2)");
                entity.Property(r => r.ElevationGainM).HasColumnType("decimal(6,2)");
                entity.Property(r => r.StartLocation).HasMaxLength(150).IsRequired();
                entity.Property(r => r.EndLocation).HasMaxLength(150).IsRequired();
                entity.Property(r => r.MapUrl).HasMaxLength(255);
            });

            // ----- Events -----
            modelBuilder.Entity<Event>(entity =>
            {
                entity.ToTable("Events");
                entity.Property(e => e.EventName).HasMaxLength(100).IsRequired();
                entity.Property(e => e.Location).HasMaxLength(150).IsRequired();
                entity.Property(e => e.Distance).HasColumnType("decimal(6,2)");
                entity.Property(e => e.EventType).HasConversion<string>().HasMaxLength(10).IsRequired();

                entity.HasOne(e => e.Organiser)
                      .WithMany(u => u.OrganisedEvents)
                      .HasForeignKey(e => e.OrganiserId)
                      .OnDelete(DeleteBehavior.Restrict); // don't cascade-delete events if a user row is removed
            });

            // ----- Categories -----
            modelBuilder.Entity<Category>(entity =>
            {
                entity.ToTable("Categories");
                entity.Property(c => c.CategoryName).HasMaxLength(50).IsRequired();
                entity.Property(c => c.DistanceKM).HasColumnType("decimal(5,2)");
                entity.Property(c => c.EntryFee).HasColumnType("decimal(8,2)");

                entity.HasOne(c => c.Event)
                      .WithMany(e => e.Categories)
                      .HasForeignKey(c => c.EventId)
                      .OnDelete(DeleteBehavior.Cascade); // deleting an event removes its categories

                entity.HasOne(c => c.Route)
                      .WithMany(r => r.Categories)
                      .HasForeignKey(c => c.RouteId)
                      .OnDelete(DeleteBehavior.Restrict)
                      .IsRequired(false);
            });

            // ----- Enrolments -----
            modelBuilder.Entity<Enrolment>(entity =>
            {
                entity.ToTable("Enrolments");
                entity.HasIndex(e => e.BibNumber).IsUnique();
                entity.Property(e => e.BibNumber).HasMaxLength(10).IsRequired();
                entity.Property(e => e.Status).HasMaxLength(20).IsRequired();

                entity.HasOne(e => e.Participant)
                      .WithMany(u => u.Enrolments)
                      .HasForeignKey(e => e.ParticipantId)
                      .OnDelete(DeleteBehavior.Restrict);

                entity.HasOne(e => e.Category)
                      .WithMany(c => c.Enrolments)
                      .HasForeignKey(e => e.CategoryId)
                      .OnDelete(DeleteBehavior.Cascade);

                // A participant may only enrol once per category
                entity.HasIndex(e => new { e.ParticipantId, e.CategoryId }).IsUnique();
            });

            // ----- Results -----
            modelBuilder.Entity<Result>(entity =>
            {
                entity.ToTable("Results");
                entity.Property(r => r.Status).HasMaxLength(20).IsRequired();

                entity.HasOne(r => r.Enrolment)
                      .WithOne(e => e.Result)
                      .HasForeignKey<Result>(r => r.EnrolmentId)
                      .OnDelete(DeleteBehavior.Cascade);

                entity.HasIndex(r => r.EnrolmentId).IsUnique(); // enforces the one-to-one
            });
        }
    }
}
