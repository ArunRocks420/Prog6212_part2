/* ============================================================
   RaceDay Database Script (UPDATED for Part 2 alignment)
   PROG6212 POE - Part 1, Section C
   Target: SQL Server Management Studio (SSMS)

   CHANGE LOG vs. original Part 1 submission:
   - Events now includes Distance (DECIMAL) and EventType (VARCHAR,
     CHECK IN 'Run','Walk','Cycle'). These were required by the Part 2
     Functional Requirements ("Each event must capture a name,
     description, date, location, distance, and event type") but were
     not present in the original ERD/script. Documented per the brief's
     instruction that deliberate ERD/SQL differences go in the README.
   ============================================================ */

IF DB_ID('RaceDayDB') IS NOT NULL
BEGIN
    ALTER DATABASE RaceDayDB SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE RaceDayDB;
END
GO

CREATE DATABASE RaceDayDB;
GO

USE RaceDayDB;
GO

/* ------------------------------------------------------------
   1. Users
   ------------------------------------------------------------ */
CREATE TABLE Users (
    UserID          INT IDENTITY(1,1) PRIMARY KEY,
    FirstName       VARCHAR(50)     NOT NULL,
    LastName        VARCHAR(50)     NOT NULL,
    Email           VARCHAR(100)    NOT NULL UNIQUE,
    PasswordHash    VARCHAR(255)    NOT NULL,
    PhoneNumber     VARCHAR(20)     NULL,
    Role            VARCHAR(20)     NOT NULL DEFAULT 'Participant',
    CreatedAt       DATETIME        NOT NULL DEFAULT GETDATE(),
    CONSTRAINT CHK_Users_Role CHECK (Role IN ('Organiser', 'Participant'))
);
GO

/* ------------------------------------------------------------
   2. Routes
   ------------------------------------------------------------ */
CREATE TABLE Routes (
    RouteID         INT IDENTITY(1,1) PRIMARY KEY,
    RouteName       VARCHAR(100)    NOT NULL,
    DistanceKM      DECIMAL(5,2)    NOT NULL,
    ElevationGainM  DECIMAL(6,2)    NOT NULL DEFAULT 0,
    StartLocation   VARCHAR(150)    NOT NULL,
    EndLocation     VARCHAR(150)    NOT NULL,
    MapURL          VARCHAR(255)    NULL
);
GO

/* ------------------------------------------------------------
   3. Events
   UPDATED: added Distance and EventType columns (see change log above).
   ------------------------------------------------------------ */
CREATE TABLE Events (
    EventID         INT IDENTITY(1,1) PRIMARY KEY,
    OrganiserID     INT             NOT NULL,
    EventName       VARCHAR(100)    NOT NULL,
    EventDate       DATE            NOT NULL,
    Location        VARCHAR(150)    NOT NULL,
    Description     VARCHAR(MAX)    NULL,
    Distance        DECIMAL(6,2)    NOT NULL,
    EventType       VARCHAR(10)     NOT NULL,
    CreatedAt       DATETIME        NOT NULL DEFAULT GETDATE(),
    CONSTRAINT FK_Events_Organiser FOREIGN KEY (OrganiserID)
        REFERENCES Users(UserID),
    CONSTRAINT CHK_Events_EventType CHECK (EventType IN ('Run', 'Walk', 'Cycle'))
);
GO

/* ------------------------------------------------------------
   4. Categories
   ------------------------------------------------------------ */
CREATE TABLE Categories (
    CategoryID      INT IDENTITY(1,1) PRIMARY KEY,
    EventID         INT             NOT NULL,
    RouteID         INT             NULL,
    CategoryName    VARCHAR(50)     NOT NULL,
    DistanceKM      DECIMAL(5,2)    NULL,
    EntryFee        DECIMAL(8,2)    NOT NULL DEFAULT 0,
    MaxParticipants INT             NOT NULL DEFAULT 100,
    CONSTRAINT FK_Categories_Event FOREIGN KEY (EventID)
        REFERENCES Events(EventID) ON DELETE CASCADE,
    CONSTRAINT FK_Categories_Route FOREIGN KEY (RouteID)
        REFERENCES Routes(RouteID)
);
GO

/* ------------------------------------------------------------
   5. Enrolments
   ------------------------------------------------------------ */
CREATE TABLE Enrolments (
    EnrolmentID     INT IDENTITY(1,1) PRIMARY KEY,
    ParticipantID   INT             NOT NULL,
    CategoryID      INT             NOT NULL,
    BibNumber       VARCHAR(10)     NOT NULL UNIQUE,
    EnrolmentDate   DATETIME        NOT NULL DEFAULT GETDATE(),
    Status          VARCHAR(20)     NOT NULL DEFAULT 'Confirmed',
    CONSTRAINT FK_Enrolments_Participant FOREIGN KEY (ParticipantID)
        REFERENCES Users(UserID),
    CONSTRAINT FK_Enrolments_Category FOREIGN KEY (CategoryID)
        REFERENCES Categories(CategoryID),
    CONSTRAINT UQ_Enrolments_Participant_Category UNIQUE (ParticipantID, CategoryID),
    CONSTRAINT CHK_Enrolments_Status CHECK (Status IN ('Confirmed', 'Cancelled', 'Waitlisted'))
);
GO

/* ------------------------------------------------------------
   6. Results
   ------------------------------------------------------------ */
CREATE TABLE Results (
    ResultID        INT IDENTITY(1,1) PRIMARY KEY,
    EnrolmentID     INT             NOT NULL UNIQUE,
    FinishTime      TIME            NULL,
    Position        INT             NULL,
    Status          VARCHAR(20)     NOT NULL DEFAULT 'Finished',
    CONSTRAINT FK_Results_Enrolment FOREIGN KEY (EnrolmentID)
        REFERENCES Enrolments(EnrolmentID),
    CONSTRAINT CHK_Results_Status CHECK (Status IN ('Finished', 'DNF', 'DQ'))
);
GO

/* ============================================================
   SEED DATA
   ============================================================ */

INSERT INTO Users (FirstName, LastName, Email, PasswordHash, PhoneNumber, Role)
VALUES
('Thabo', 'Nkosi', 'thabo.nkosi@raceday.co.za', 'hashed_pw_001', '0821234567', 'Organiser'),
('Sarah', 'Botha', 'sarah.botha@raceday.co.za', 'hashed_pw_002', '0837654321', 'Organiser');

INSERT INTO Users (FirstName, LastName, Email, PasswordHash, PhoneNumber, Role)
VALUES
('Lindiwe', 'Dlamini', 'lindiwe.d@example.com', 'hashed_pw_003', '0731112222', 'Participant'),
('James', 'van der Merwe', 'james.vdm@example.com', 'hashed_pw_004', '0823334444', 'Participant');

INSERT INTO Routes (RouteName, DistanceKM, ElevationGainM, StartLocation, EndLocation, MapURL)
VALUES
('Comrades-style Ultra Route', 87.00, 1200.00, 'Pietermaritzburg', 'Durban', 'https://maps.example.com/route1'),
('Cape Town Cycle Tour Route', 109.00, 850.00, 'Cape Town CBD', 'Cape Town CBD', 'https://maps.example.com/route2'),
('Soweto Marathon Route', 42.20, 300.00, 'FNB Stadium', 'FNB Stadium', 'https://maps.example.com/route3');

INSERT INTO Events (OrganiserID, EventName, EventDate, Location, Description, Distance, EventType)
VALUES
(1, 'Comrades Marathon', '2027-06-13', 'Pietermaritzburg to Durban', 'Iconic ultra-marathon road race.', 87.00, 'Run'),
(2, 'Cape Town Cycle Tour', '2027-03-08', 'Cape Town', 'Premier timed cycling event.', 109.00, 'Cycle'),
(1, 'Soweto Marathon', '2027-11-07', 'Johannesburg', 'Community marathon and fun run.', 42.20, 'Run');

INSERT INTO Categories (EventID, RouteID, CategoryName, DistanceKM, EntryFee, MaxParticipants)
VALUES
(1, 1, 'Ultra Marathon - 87km', 87.00, 950.00, 5000),
(2, 2, 'Cycle Tour - 109km', 109.00, 650.00, 8000),
(3, 3, 'Full Marathon - 42.2km', 42.20, 350.00, 3000),
(3, 3, '10km Fun Run', 10.00, 150.00, 1500);

INSERT INTO Enrolments (ParticipantID, CategoryID, BibNumber, Status)
VALUES
(3, 1, 'CM-1001', 'Confirmed'),
(4, 2, 'CT-2001', 'Confirmed'),
(3, 4, 'SW-4001', 'Confirmed');

INSERT INTO Results (EnrolmentID, FinishTime, Position, Status)
VALUES
(1, '08:42:15', 214, 'Finished'),
(2, '03:15:40', 89, 'Finished');
GO
